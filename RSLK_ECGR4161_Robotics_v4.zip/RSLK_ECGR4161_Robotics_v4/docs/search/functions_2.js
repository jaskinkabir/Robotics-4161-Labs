var searchData=
[
  ['directionbackward_145',['directionBackward',['../class_romi___motor___power.html#ab932f266abe2d43e8e07c1ef687e9789',1,'Romi_Motor_Power']]],
  ['directionforward_146',['directionForward',['../class_romi___motor___power.html#a752d0775f6737616d23ce8f752cf7fab',1,'Romi_Motor_Power']]],
  ['disablemotor_147',['disableMotor',['../class_romi___motor___power.html#a0c58741d295dd00e9efef4829953bc6c',1,'Romi_Motor_Power::disableMotor()'],['../_simple_r_s_l_k_8h.html#a4d6d0ccc51bb5836071173736b104367',1,'disableMotor():&#160;SimpleRSLK.cpp']]]
];
