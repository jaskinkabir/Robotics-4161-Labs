var searchData=
[
  ['pausemotor_68',['pauseMotor',['../class_romi___motor___power.html#a7f13f8a8623c4d78fe1c94b92fc667af',1,'Romi_Motor_Power::pauseMotor()'],['../_simple_r_s_l_k_8h.html#a957692b579023b83201b6e6c413e30f1',1,'pauseMotor():&#160;SimpleRSLK.cpp']]]
];
